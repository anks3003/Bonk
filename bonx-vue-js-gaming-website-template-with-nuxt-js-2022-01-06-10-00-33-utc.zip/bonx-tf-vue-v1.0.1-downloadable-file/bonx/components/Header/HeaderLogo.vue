<template>
    <!-- Header Logo Start -->
    <NuxtLink to="/">
        <img src="/images/logo.webp" alt="Header Logo">
    </NuxtLink>
    <!-- Header Logo End -->
</template>