<template>
    <!-- Button Start -->
    <NuxtLink to="/contact" style="background-image:url(/images/others/btn-bg.webp);" class="w-230 md:text-2xl md:leading-12 h-73 flex items-center text-white font-bold justify-center font-exo group hover:opacity-80 leading-70 text-xl">
        Play Now
        <img class="ml-3 w-5 h-5 group-hover:ml-4 transition-all" src="/images/icon/arrrow-icon.webp" alt="Arrow Icon">
    </NuxtLink>
    <!-- Button End -->
</template>